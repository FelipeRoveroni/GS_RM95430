﻿using GS.Application.Dtos;
using GS.Domain.Entities;
using GS.Domain.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using System.Net;

namespace GS.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsuarioController : ControllerBase
    {
        private readonly IUsuarioApplicationService _applicationService;

        public UsuarioController(IUsuarioApplicationService applicationService)
        {
            _applicationService = applicationService;
        }

        [HttpGet]
        [SwaggerOperation(Summary = "Lista de Todos os usuarios", Description = "Este endpoint retorna uma lista completa com todos os Usuarios cadastrados no sistema.")]
        [Produces(typeof(IEnumerable<UsuarioEntity>))]
        public IActionResult Get()
        {
            var user = _applicationService.ObterTodosUsuarios();

            if (user is not null) 
                return Ok(user);

            return BadRequest("Não Foi possivel obter todos os Usuarios");
        }

        [HttpGet("{id}")]
        [SwaggerOperation(Summary = "Lista Usuario Especifico", Description = "Este endpoint retorna um Usuario especifico com base no ID.")]
        [SwaggerResponse(200, "Usuario encontrado com sucesso", typeof(UsuarioEntity))]
        [SwaggerResponse(400, "Usuario não encontrado")]
        [SwaggerResponse(404, "Falha ao encontrar o Usuario")]
        [Produces(typeof(UsuarioEntity))]
        public IActionResult GetPorId(int id)
        {
            var user = _applicationService.ObterUsuarioPorId(id);

            if (user is not null)
                return Ok(user);

            return BadRequest("Não Foi possivel obter Usuario");

        }

        [HttpPost]
        [SwaggerOperation(Summary = "Adiciona um novo Usuario", Description = "Este endpoint cria um novo usuario com base nas informações fornecidas")]
        [SwaggerResponse(200, "Usuario criado com sucesso")]
        [SwaggerResponse(404, "Falha para criar o Usuario")]
        [Produces(typeof(UsuarioEntity))]
        public IActionResult Post(UsuarioDto entity)
        {
            try
            {
                var user = _applicationService.AdicionarUsuario(entity);

                if (user is not null)
                    return Ok(user);

                return BadRequest("Não Foi possivel adicionar Usuario");
            }
            catch (Exception ex)
            {
                return BadRequest(new 
                { 
                    Error = ex.Message,
                    Status = HttpStatusCode.BadRequest,
                });
            }
        }

        [HttpPut("{id}")]
        [SwaggerOperation(Summary = "Edita um Usuario existente", Description = "Este endpoint atualiza as informações de um usuario já existente com bsae no ID fornecido.")]
        [SwaggerResponse(200, "Usuario editado com sucesso")]
        [SwaggerResponse(404, "Falaha ao editar o Usuario")]
        [Produces(typeof(UsuarioEntity))]
        public IActionResult Put(int id, UsuarioDto entity)
        {
            try
            {
                var user = _applicationService.EditarUsuario(id, entity);

                if (user is not null)
                    return Ok(user);

                return BadRequest("Não foi possivel editar o Usuario");
            }
            catch (Exception ex)
            {
                return BadRequest(new
                {
                    Error = ex.Message,
                    Status = HttpStatusCode.BadRequest,
                });
            }
        }

        [HttpDelete("{id}")]
        [SwaggerOperation(Summary = "Deleta um Usuario existente", Description = "Este endpoint deleta as informações do usuario com base no ID fornecido")]
        [SwaggerResponse(200, "Usuario removido com sucesso")]
        [SwaggerResponse(404, "Falha ao excluir o Usuario")]
        [Produces(typeof(UsuarioEntity))]
        public IActionResult Delete(int id)
        {
            var user = _applicationService.RemoverUsuario(id);

            if (user is not null)
                return Ok(user);

            return BadRequest("Não foi possivel deletar o Usuario");
        }

        [HttpGet("busca/localizacao/{cep}")]
        [SwaggerOperation(Summary = "Busca a Localizacao com Base no CEP", Description = "Este endpoint busca uma localização especifica com Base no CEP fornecido")]
        [SwaggerResponse(200, "Localizacao encontrada com sucesso")]
        [SwaggerResponse(404, "Falha ao encontrar a Localizacao")]
        [Produces<Localizacao>]
        public async Task<IActionResult> GetDataService(string cep)
        {
            var local = await _applicationService.ObterLocalizacaoPorCepAsync(cep);

            if (local is not null)
                return Ok(local);

            return BadRequest("Não foi possivel obter os dados da localização informada");
        }

    }
}
