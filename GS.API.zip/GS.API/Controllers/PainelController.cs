﻿using GS.Domain.Entities;
using GS.Domain.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;

namespace GS.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PainelController : ControllerBase
    {
        private readonly IPainelApplicationService _painelApplicationService;

        public PainelController(IPainelApplicationService painelApplicationService)
        {
            _painelApplicationService = painelApplicationService;
        }

        [HttpGet]
        [SwaggerOperation(Summary = "Lista de Todos os Paineis Solares", Description = "Este endpoint retorna uma lista completa com todos os Paines Solares cadastrados no sistema.")]
        [Produces(typeof(IEnumerable<PainelEntity>))]
        public IActionResult Get()
        {
            var v_painel = _painelApplicationService.ObterTodosPaineis();

            if (v_painel is not null)
                return Ok(v_painel);

            return BadRequest("Não Foi possivel obter todos os Paineis");
        }

        [HttpGet("{id}")]
        [SwaggerOperation(Summary = "Lista Painel Solar", Description = "Este endpoint retorna um Painel Solcar especifico com base no ID.")]
        [SwaggerResponse(200, "Painel Solar encontrado com sucesso", typeof(PainelEntity))]
        [SwaggerResponse(400, "Painel Solar não encontrado")]
        [SwaggerResponse(404, "Falha ao encontrar o Painel Solar")]
        [Produces(typeof(PainelEntity))]
        public IActionResult GetPorId(int id)
        {
            var v_painel = _painelApplicationService.ObterPainelPorId(id);

            if (v_painel is not null)
                return Ok(v_painel);

            return BadRequest("Não Foi possivel obter nenhum Painel");
        }

        [HttpPost]
        [SwaggerOperation(Summary = "Adiciona um novo Painel Solar", Description = "Este endpoint cria um novo Painel Solar com base nas informações fornecidas")]
        [SwaggerResponse(200, "Painel SOlar criado com sucesso")]
        [SwaggerResponse(404, "Falha para criar o Painel Solar")]
        [Produces(typeof(PainelEntity))]
        public IActionResult Post([FromBody] PainelEntity entity)
        {
            var v_painel = _painelApplicationService.AdicionarPainel(entity);

            if (v_painel is not null)
                return Ok(v_painel);

            return BadRequest("Não Foi possivel adicionar um Novo painel");
        }

        [HttpPut]
        [SwaggerOperation(Summary = "Edita um Painel Solar existente", Description = "Este endpoint atualiza as informações de um Painel Solar já existente com bsae no ID fornecido.")]
        [SwaggerResponse(200, "Painel Solar editado com sucesso")]
        [SwaggerResponse(404, "Falaha ao editar o Painel Solar")]
        [Produces(typeof(PainelEntity))]
        public IActionResult Put([FromBody] PainelEntity entity)
        {
            var v_painel = _painelApplicationService.EditarPainel(entity);

            if (v_painel is not null)
                return Ok(v_painel);

            return BadRequest("Não foi possivel editar o Painel");
        }

        [HttpDelete("{id}")]
        [SwaggerOperation(Summary = "Deleta um Painel Solar existente", Description = "Este endpoint deleta as informações do Painel Solar com base no ID fornecido")]
        [SwaggerResponse(200, "Painel Solar removido com sucesso")]
        [SwaggerResponse(404, "Falha ao excluir o Painel Solar")]
        [Produces(typeof(PainelEntity))]
        public IActionResult Delete(int id)
        {
            var v_painel = _painelApplicationService.RemoverPainel(id);

            if (v_painel is not null)
                return Ok(v_painel);

            return BadRequest("Não foi possivel deletar o Painel");
        }
    }
}
